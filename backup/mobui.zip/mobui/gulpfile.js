const path          = require('path');
const fs            = require('fs');
const gulp          = require('gulp');
const scss          = require('gulp-sass');
const header        = require('gulp-header');
const tap           = require('gulp-tap');
const nano          = require('gulp-cssnano');
const postcss       = require('gulp-postcss');
const autoprefixer  = require('autoprefixer');
const rename        = require('gulp-rename');
const sourcemaps    = require('gulp-sourcemaps');
const browserSync   = require('browser-sync');
const yargs         = require('yargs')
                        .options({
                            'w': {
                                alias: 'watch',
                                type: 'boolean'
                            },
                            's': {
                                alias: 'server',
                                type: 'boolean'
                            },
                            'p': {
                                alias: 'port',
                                type: 'number'
                            }
                        }).argv;

const pkg           = require('./package.json');
const option        = {base: 'src'};
const dist          = __dirname + '/dist';

/***************Function Define ******************/
function buildStyle() {
    var banner =
        `/*!
          * MobUI v<%= pkg.version %> (<%= pkg.homepage %>)
          * Copyright <%= new Date().getFullYear() %> JMwill
          * Licensed under the <%= pkg.license %> license
          */
          `;
    return gulp.src('src/mobui.scss', option)
        .pipe(sourcemaps.init())
        .pipe(scss().on('error', scss.logError))
        .pipe(postcss([autoprefixer(['iOS >= 7', 'Android >= 4.1'])]))
        .pipe(header(banner, { pkg : pkg } ))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}))
        .pipe(nano({
            zindex: false,
            autoprefixer: false
        }))
        .pipe(rename(function (path) {
            path.basename += '.min';
        }))
        .pipe(gulp.dest(dist));
}

function buildExampleAssets() {
    return gulp.src('example/**/*.?(png|jpg|gif|js)', option)
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}));
}

function buildExampleStyle() {
    return gulp.src('example/example.scss', option)
        .pipe(scss().on('error', scss.logError))
        .pipe(postcss([autoprefixer(['iOS >= 7', 'Android >= 4.1'])]))
        .pipe(nano({
            zindex: false,
            autoprefixer: false
        }))
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}));
}

function buildExampleHtml() {
    return gulp.src('example/index.html', option)
        .pipe(tap(function (file){
            var dir = path.dirname(file.path);
            var contents = file.contents.toString();
            contents = contents.replace(/<link\s+rel="import"\s+href="(.*)">/gi, function (match, $1){
                var filename = path.join(dir, $1);
                var id = path.basename(filename, '.html');
                var content = fs.readFileSync(filename, 'utf-8');
                return '<script type="text/html" id="tpl_'+ id +'">\n'+ content +'\n</script>';
            });
            file.contents = new Buffer(contents);
        }))
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}));
}

function watch() {
    gulp.watch('src/style/**/*', gulp.parallel('build:style'));
    gulp.watch('example/example.scss', gulp.parallel('build:example:style'));
    gulp.watch('example/**/*.?(png|jpg|gif|js)', gulp.parallel('build:example:assets'));
    gulp.watch('src/**/*.html', gulp.parallel('build:example:html'));
}

function server() {
    yargs.p = yargs.p || 8080;
    browserSync.init({
        server: {
            baseDir: "./example"
        },
        ui: {
            port: yargs.p + 1,
            weinre: {
                port: yargs.p + 2
            }
        },
        port: yargs.p,
        // startPath: '/example'
    });
}

function defaultFun(done) {
    console.log(yargs.s, yargs.w);
    if (yargs.s) {
        server();
    }

    if (yargs.w) {
        watch();
    }
}
/*************************************************/
gulp.task('build:style', buildStyle);
gulp.task('build:example:assets', buildExampleAssets);
gulp.task('build:example:style', buildExampleStyle);
gulp.task('build:example:html', buildExampleHtml);
gulp.task('build:example', gulp.parallel('build:example:assets', 'build:example:style', 'build:example:html'));

gulp.task('release', gulp.parallel('build:style', 'build:example'));
gulp.task('watch', gulp.series('release'), watch);

gulp.task('server', server);

// 参数说明
//  -w: 实时监听
//  -s: 启动服务器
//  -p: 服务器启动端口，默认8080
gulp.task('default', gulp.series('release', defaultFun));
