from distutils.core import setup

setup(
    name            = 'nester',
    version         = '1.0.0',
    py_modules      = ['nester'],
    author          = 'will',
    author_email    = '787505998@qq.com',
    url             = 'http://www.jmwill.com',
    description     = 'A simple printer of nested lists',
)